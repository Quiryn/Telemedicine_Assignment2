<html>
<head>
    <title>Clickjack test page</title>
</head>
<body>
<p>Website is vulnerable to clickjacking!</p>
<iframe src="http://localhost:20047/tour/Edit/1" width="500" height="500"></iframe>
</body>
</html>

