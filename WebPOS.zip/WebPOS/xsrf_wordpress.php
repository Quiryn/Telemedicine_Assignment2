<html>
<head>
    <title>Clickjack test page</title>
</head>
<body>
<p>Website is vulnerable to clickjacking!</p>
<iframe src="http://localhost:85/frameworks/wordpress/wp-admin/post.php?post=1&action=edit" width="500" height="500"></iframe>
</body>
</html>