<html>
<head>
    <title>Clickjack test page</title>
</head>
<body>
<p>Website is vulnerable to clickjacking!</p>
<iframe src="http://webpos-project.azurewebsites.net/frmAddProduct.php" width="500" height="500"></iframe>
</body>
</html>