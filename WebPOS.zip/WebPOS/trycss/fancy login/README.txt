A Pen created at CodePen.io. You can find this one at http://codepen.io/ivanovic/pen/qdzFc.

 This fantastic registration form is simple and attractive for any website