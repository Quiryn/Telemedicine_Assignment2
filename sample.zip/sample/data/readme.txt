Hosted using pythons simple http server:
'python -m SimpleHTTPServer <portnr>'

(Or any other way you want to)